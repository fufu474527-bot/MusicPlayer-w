package com.example.musicplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONArray
import org.json.JSONObject

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri)

fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder().setTitle(title).setArtist(artist).build()
    )
    .build()

fun loadSongs(ctx: Context): List<Song> {
    val list = mutableListOf<Song>()
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST
    )
    ctx.contentResolver.query(
        collection, projection,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${MediaStore.Audio.Media.TITLE} ASC"
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            list += Song(
                id,
                c.getString(1) ?: "بدون عنوان",
                c.getString(2) ?: "غير معروف",
                ContentUris.withAppendedId(collection, id)
            )
        }
    }
    return list
}

/** تخزين قوائم التشغيل محلياً (اسم القائمة -> أرقام الأغاني). */
class PlaylistStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("playlists", Context.MODE_PRIVATE)

    fun load(): Map<String, List<Long>> {
        val json = JSONObject(prefs.getString("data", "{}") ?: "{}")
        val out = linkedMapOf<String, List<Long>>()
        json.keys().forEach { name ->
            val arr = json.getJSONArray(name)
            out[name] = List(arr.length()) { arr.getLong(it) }
        }
        return out
    }

    fun save(map: Map<String, List<Long>>) {
        val json = JSONObject()
        map.forEach { (name, ids) -> json.put(name, JSONArray(ids)) }
        prefs.edit().putString("data", json.toString()).apply()
    }
}
