package com.example.musicplayer

import android.Manifest
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { PlayerScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen() {
    val ctx = LocalContext.current
    val store = remember { PlaylistStore(ctx) }

    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    var playlists by remember { mutableStateOf(store.load()) }
    var tab by remember { mutableIntStateOf(0) }
    var openPlaylist by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var songToAdd by remember { mutableStateOf<Song?>(null) }
    var showNewPlaylist by remember { mutableStateOf(false) }

    // حالة المشغل
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var playing by remember { mutableStateOf(false) }
    var currentId by remember { mutableStateOf<String?>(null) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var position by remember { mutableFloatStateOf(0f) }
    var duration by remember { mutableFloatStateOf(1f) }

    fun updatePlaylists(newMap: Map<String, List<Long>>) {
        playlists = newMap
        store.save(newMap)
    }

    // الأذونات
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val audioPerm = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        granted = result[audioPerm] == true
        if (granted) songs = loadSongs(ctx)
    }
    LaunchedEffect(Unit) {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.READ_MEDIA_AUDIO
            perms += Manifest.permission.POST_NOTIFICATIONS
        } else {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        permLauncher.launch(perms.toTypedArray())
    }

    // الاتصال بخدمة التشغيل
    DisposableEffect(Unit) {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = future.get()
            playing = c.isPlaying
            currentId = c.currentMediaItem?.mediaId
            shuffle = c.shuffleModeEnabled
            repeat = c.repeatMode
            controller = c
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }

    DisposableEffect(controller) {
        val c = controller
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(item: androidx.media3.common.MediaItem?, reason: Int) {
                currentId = item?.mediaId
            }
            override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffle = enabled }
            override fun onRepeatModeChanged(mode: Int) { repeat = mode }
        }
        c?.addListener(listener)
        onDispose { c?.removeListener(listener) }
    }

    LaunchedEffect(controller, playing, currentId) {
        while (true) {
            controller?.let {
                position = it.currentPosition.toFloat()
                duration = it.duration.coerceAtLeast(1L).toFloat()
            }
            delay(500)
        }
    }

    fun playQueue(list: List<Song>, index: Int) {
        controller?.apply {
            setMediaItems(list.map { it.toMediaItem() }, index, 0L)
            prepare()
            play()
        }
    }

    val songsById = remember(songs) { songs.associateBy { it.id.toString() } }
    val currentSong = currentId?.let { songsById[it] }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(openPlaylist ?: "مشغل الأغاني")
                        Text(
                            "وحيد تكنولوجي",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    if (openPlaylist != null) {
                        IconButton({ openPlaylist = null }) {
                            Icon(Icons.Default.ArrowBack, "رجوع")
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {

            if (openPlaylist == null) {
                TabRow(selectedTabIndex = tab) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("كل الأغاني") })
                    Tab(tab == 1, { tab = 1 }, text = { Text("القوائم") })
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    !granted -> Centered("يلزم السماح بالوصول إلى الملفات الصوتية")

                    openPlaylist != null -> {
                        val name = openPlaylist!!
                        val list = (playlists[name] ?: emptyList()).mapNotNull { songsById[it.toString()] }
                        if (list.isEmpty()) Centered("القائمة فارغة")
                        else Column {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button({ playQueue(list, 0) }) { Text("تشغيل الكل") }
                                OutlinedButton({
                                    updatePlaylists(playlists - name); openPlaylist = null
                                }) { Text("حذف القائمة") }
                            }
                            LazyColumn {
                                itemsIndexed(list) { i, s ->
                                    SongRow(
                                        s, s.id.toString() == currentId,
                                        onClick = { playQueue(list, i) },
                                        actionIcon = Icons.Default.Delete,
                                        actionDesc = "إزالة من القائمة",
                                        onAction = {
                                            updatePlaylists(
                                                playlists + (name to (playlists[name].orEmpty() - s.id))
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    }

                    tab == 0 -> {
                        val filtered = remember(songs, query) {
                            if (query.isBlank()) songs
                            else songs.filter {
                                it.title.contains(query, true) || it.artist.contains(query, true)
                            }
                        }
                        Column {
                            OutlinedTextField(
                                value = query, onValueChange = { query = it },
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                placeholder = { Text("ابحث عن أغنية أو فنان") },
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                singleLine = true
                            )
                            if (filtered.isEmpty()) Centered("لا توجد أغاني")
                            else LazyColumn {
                                itemsIndexed(filtered) { i, s ->
                                    SongRow(
                                        s, s.id.toString() == currentId,
                                        onClick = { playQueue(filtered, i) },
                                        actionIcon = Icons.Default.Add,
                                        actionDesc = "إضافة إلى قائمة",
                                        onAction = { songToAdd = s }
                                    )
                                }
                            }
                        }
                    }

                    else -> Column {
                        Button(
                            { showNewPlaylist = true },
                            Modifier.padding(12.dp)
                        ) { Text("قائمة جديدة") }
                        if (playlists.isEmpty()) Centered("لا توجد قوائم بعد")
                        else LazyColumn {
                            itemsIndexed(playlists.keys.toList()) { _, name ->
                                ListItem(
                                    headlineContent = { Text(name) },
                                    supportingContent = { Text("${playlists[name]?.size ?: 0} أغنية") },
                                    leadingContent = { Icon(Icons.Default.LibraryMusic, null) },
                                    modifier = Modifier.clickable { openPlaylist = name }
                                )
                            }
                        }
                    }
                }
            }

            // المشغل المصغّر
            if (currentSong != null) {
                Surface(tonalElevation = 3.dp) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(currentSong.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        Text(currentSong.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        Slider(
                            value = position.coerceIn(0f, duration),
                            onValueChange = { position = it; controller?.seekTo(it.toLong()) },
                            valueRange = 0f..duration
                        )
                        Row(
                            Modifier.fillMaxWidth(),
                            Arrangement.SpaceEvenly, Alignment.CenterVertically
                        ) {
                            IconButton({ controller?.shuffleModeEnabled = !shuffle }) {
                                Icon(
                                    Icons.Default.Shuffle, "عشوائي",
                                    tint = if (shuffle) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton({ controller?.seekToPrevious() }) {
                                Icon(Icons.Default.SkipPrevious, "السابق")
                            }
                            FilledIconButton({
                                controller?.let { if (it.isPlaying) it.pause() else it.play() }
                            }) {
                                Icon(
                                    if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    "تشغيل/إيقاف"
                                )
                            }
                            IconButton({ controller?.seekToNext() }) {
                                Icon(Icons.Default.SkipNext, "التالي")
                            }
                            IconButton({
                                controller?.repeatMode = when (repeat) {
                                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                    else -> Player.REPEAT_MODE_OFF
                                }
                            }) {
                                Icon(
                                    if (repeat == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne
                                    else Icons.Default.Repeat,
                                    "تكرار",
                                    tint = if (repeat != Player.REPEAT_MODE_OFF)
                                        MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة: قائمة جديدة
    if (showNewPlaylist) {
        NameDialog(
            title = "اسم القائمة",
            onDismiss = { showNewPlaylist = false },
            onConfirm = { name ->
                if (name.isNotBlank() && name !in playlists) updatePlaylists(playlists + (name to emptyList()))
                showNewPlaylist = false
            }
        )
    }

    // نافذة: إضافة أغنية إلى قائمة
    songToAdd?.let { song ->
        AlertDialog(
            onDismissRequest = { songToAdd = null },
            title = { Text("إضافة إلى قائمة") },
            text = {
                if (playlists.isEmpty()) Text("أنشئ قائمة أولاً من تبويب القوائم")
                else Column {
                    playlists.keys.forEach { name ->
                        TextButton({
                            val ids = playlists[name].orEmpty()
                            if (song.id !in ids) updatePlaylists(playlists + (name to (ids + song.id)))
                            songToAdd = null
                        }) { Text(name) }
                    }
                }
            },
            confirmButton = { TextButton({ songToAdd = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun Centered(text: String) {
    Box(Modifier.fillMaxSize(), Alignment.Center) { Text(text) }
}

@Composable
fun SongRow(
    song: Song,
    isCurrent: Boolean,
    onClick: () -> Unit,
    actionIcon: androidx.compose.ui.graphics.vector.ImageVector,
    actionDesc: String,
    onAction: () -> Unit
) {
    ListItem(
        headlineContent = { Text(song.title, maxLines = 1) },
        supportingContent = { Text(song.artist, maxLines = 1) },
        leadingContent = {
            Icon(if (isCurrent) Icons.Default.GraphicEq else Icons.Default.MusicNote, null)
        },
        trailingContent = {
            IconButton(onAction) { Icon(actionIcon, actionDesc) }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
fun NameDialog(title: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = { TextButton({ onConfirm(text.trim()) }) { Text("إنشاء") } },
        dismissButton = { TextButton(onDismiss) { Text("إلغاء") } }
    )
}
